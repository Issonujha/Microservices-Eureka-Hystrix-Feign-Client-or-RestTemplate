package EdTech.Course.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import EdTech.Course.dto.CourseDto;
import EdTech.Course.dto.ResponseMessage;
import EdTech.Course.dto.UserDetailsResponse;
import EdTech.Course.model.Course;
import EdTech.Course.model.CourseMaterial;
import EdTech.Course.model.Enrollment;
import EdTech.Course.repository.CourseRepository;

@Service
public class CourseService {
	
	
	private CourseRepository courseRepository;
	private RestTemplate restTemplate;
	
	@Autowired
	public CourseService(CourseRepository courseRepository, RestTemplate restTemplate) {
		this.courseRepository = courseRepository;
		this.restTemplate = restTemplate;
	}
	

	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	public Course getCourseById(Long id) {
		Optional<Course> course = courseRepository.findById(id);
		return course.isPresent() ? course.get() : null;
	}

	public Course getCourseByName(String name) {
		return courseRepository.findByName(name);
	}

	public List<CourseMaterial> getCourseMaterialByCourseId(Long id) {
		Optional<Course> course = courseRepository.findById(id);
		return course != null ? course.get().getCourseMaterial() : null;
	}

	public Course getCourseByInstructor(String instructor) {
		return courseRepository.findByInstructor(instructor);
	}

	public ResponseMessage createCourse(CourseDto courseDto) {
		Course course = Course.builder().amount(courseDto.getAmount()).description(courseDto.getDescription())
				.instructor(courseDto.getInstructor()).name(courseDto.getName()).build();
		List<CourseMaterial> courseMaterials = courseDto.getCourseMaterial();
		if (courseMaterials != null) {
			for (CourseMaterial material : courseMaterials) {
				material.setCourse(course); // Set the course reference
			}
			course.setCourseMaterial(courseMaterials); // Assign materials to the course
		}

		List<Enrollment> enrollments = courseDto.getEnrollments();
		if (enrollments != null) {
			for (Enrollment enrollment : enrollments) {
				enrollment.setCourse(course); // Set the course reference
			}
			course.setEnrollment(enrollments); // Assign materials to the course
		}
		courseRepository.save(course);
		return new ResponseMessage("Course Added Successfully");
	}

	public ResponseMessage updateCourse(Long id, CourseDto updatedCourseDto) {
		Course course = getCourseById(id);
		if (course != null) {
			course = Course.builder().id(id).amount(updatedCourseDto.getAmount())
					.description(updatedCourseDto.getDescription()).instructor(updatedCourseDto.getInstructor())
					.name(updatedCourseDto.getName()).build();
			List<CourseMaterial> courseMaterials = updatedCourseDto.getCourseMaterial();
			if (courseMaterials != null) {
				for (CourseMaterial material : courseMaterials) {
					material.setCourse(course); // Set the course reference
				}
				course.setCourseMaterial(courseMaterials); // Assign materials to the course
			}

			List<Enrollment> enrollmentls = updatedCourseDto.getEnrollments();
			if (enrollmentls != null) {
				for (Enrollment enrollment : enrollmentls) {
					enrollment.setCourse(course); // Set the course reference
				}
				course.setEnrollment(enrollmentls); // Assign materials to the course
			}
			courseRepository.save(course);
		}
		return new ResponseMessage("Course Updated Successfully");
	}

	public ResponseMessage deleteCourse(Long id) {
		Course course = getCourseById(id);
		if (course != null) {
			courseRepository.delete(course);
		}
		return new ResponseMessage("Course Deleted Successfully");
	}

	public ResponseMessage createEnrollmentForCourse(String authorization, Long courseId, Long userId) {
		Course course = getCourseById(courseId);
		if (course != null && authorization != null && !authorization.isEmpty()) {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", authorization);
			HttpEntity<Void> entity = new HttpEntity<>(headers);
			ResponseEntity<UserDetailsResponse> userDetailsResponse = restTemplate
					.exchange("http://localhost:8083/user/" + userId, HttpMethod.GET, entity, UserDetailsResponse.class);
			if (userDetailsResponse.getBody() != null) {
				Enrollment enrollment = Enrollment.builder().userId(userId).course(course).build();
				if (course.getEnrollment() != null) {
					course.getEnrollment().add(enrollment);
				} else {
					course.setEnrollment(Arrays.asList(enrollment));
				}
				courseRepository.save(course);
			}
		}
		return new ResponseMessage("Student Enrolled Successfully");
	}
	
	

}
